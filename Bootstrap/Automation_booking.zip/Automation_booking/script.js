document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
    
    // Date picker initialization for search form
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    document.getElementById('pickupDate').min = formatDate(today);
    document.getElementById('returnDate').min = formatDate(tomorrow);
    
    document.getElementById('pickupDate').addEventListener('change', function() {
        const pickupDate = new Date(this.value);
        const minReturnDate = new Date(pickupDate);
        minReturnDate.setDate(minReturnDate.getDate() + 1);
        
        document.getElementById('returnDate').min = formatDate(minReturnDate);
        
        // If current return date is before new min date, reset it
        const returnDate = new Date(document.getElementById('returnDate').value);
        if (returnDate < minReturnDate) {
            document.getElementById('returnDate').value = formatDate(minReturnDate);
        }
    });
    
    // Similar date validation for booking form
    document.getElementById('bookingPickupDate').min = formatDate(today);
    document.getElementById('bookingReturnDate').min = formatDate(tomorrow);
    
    document.getElementById('bookingPickupDate').addEventListener('change', function() {
        const pickupDate = new Date(this.value);
        const minReturnDate = new Date(pickupDate);
        minReturnDate.setDate(minReturnDate.getDate() + 1);
        
        document.getElementById('bookingReturnDate').min = formatDate(minReturnDate);
        
        // If current return date is before new min date, reset it
        const returnDate = new Date(document.getElementById('bookingReturnDate').value);
        if (returnDate < minReturnDate) {
            document.getElementById('bookingReturnDate').value = formatDate(minReturnDate);
        }
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                const offset = 70; // Adjust for fixed navbar height
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - offset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Helper function to format date as YYYY-MM-DD
    function formatDate(date) {
        const d = new Date(date);
        let month = '' + (d.getMonth() + 1);
        let day = '' + d.getDate();
        const year = d.getFullYear();
        
        if (month.length < 2) 
            month = '0' + month;
        if (day.length < 2) 
            day = '0' + day;
        
        return [year, month, day].join('-');
    }
    
    // Booking form submission
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Here you would typically send the data to a server
            // For demo purposes, we'll just show an alert
            alert('Thank you for your booking! We will contact you shortly to confirm your reservation.');
            this.reset();
            this.classList.remove('was-validated');
        });
    }
    
    // Contact form submission
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Here you would typically send the data to a server
            // For demo purposes, we'll just show an alert
            alert('Thank you for your message! We will get back to you soon.');
            this.reset();
            this.classList.remove('was-validated');
        });
    }
});